export interface ShareableLinkOptions {
    allowEdit: boolean;
    allowDownload: boolean;
    expiresAt: string;
    password: string;
}
