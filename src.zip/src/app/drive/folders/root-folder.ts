export interface RootFolder {
    id: 'root';
    hash: 'root';
    path: '';
    type: 'folder';
}

export const ROOT_FOLDER: RootFolder = {
    id: 'root',
    hash: 'root',
    path: '',
    type: 'folder',
};
