export const SUPPORTED_ENTRY_TYPES = [
    'audio',
    'video',
    'text',
    'pdf',
    'archive',
    'folder',
    'shared-folder',
    'image',
    'powerPoint',
    'word',
    'spreadsheet',
];
