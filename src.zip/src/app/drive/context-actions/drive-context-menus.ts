import { DriveContextMenuComponent } from './components/drive-context-menu/drive-context-menu.component';

export const DRIVE_CONTEXT_MENUS = {
    entry: DriveContextMenuComponent,
};
