export enum LoadingToastMessages {
    copyEntries =  'Copying items...',
    emptyTrash = 'Emptying trash...',
    moveEntries = 'Moving items...',
}
