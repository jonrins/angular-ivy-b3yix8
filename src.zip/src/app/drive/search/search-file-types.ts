export const SEARCH_FILE_TYPES = [
    {name: 'Folders', type: 'folder'},
    {name: 'Images', type: 'image'},
    {name: 'Text documents', type: 'text'},
    {name: 'Video', type: 'video'},
    {name: 'Audio', type: 'audio'},
    {name: 'PDFs', type: 'pdf'},
];
