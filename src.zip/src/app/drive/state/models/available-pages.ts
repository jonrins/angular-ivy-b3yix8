export type DrivePageType = 'root'|'recent'|'trash'|'starred'|'folder'|'shares'|'search';
